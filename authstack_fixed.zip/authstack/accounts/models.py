# Not strictly needed for roles/permissions; using Django's built-in User/Group/Permission
from django.db import models
